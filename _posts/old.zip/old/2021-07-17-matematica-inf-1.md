---
layout: post
title: "(788) - Matemática para informática 1"
description: 'Materia del primer cuatrimestre del primer año'
date:   2021-07-17 17:46:41 -0300
categories: Materias
by: 'Informatica UNAHUR'
icon: 'credit-card'
questions:
  - question: 'OBJETIVOS'
    answer: 'Adquirir la habilidad para interpretar y resolver problemas, aplicando los contenidos expuestos. Es matemática DISCRETA, y los principales temas son: Elementos de lógica proposicional y de primer orden. Teoría de la Estructuras Discretas. Teoría básica de conjuntos. '
    modalidad: "MODALIDAD COMBINADA"
  - question: '¿Cómo se cursa?'
    answer: 'Se utiliza el Campus Virtual como espacio donde se informan novedades y se van habilitando contenidos.
    Se dictan clases presenciales semanales obligatorias para el desarrollo teórico con ejercicios de aplicación.
    Se dictan clases de prácticas virtuales de resolución de ejercicios que pueden ser sincrónicas o asincrónicas'
  - question: 'Otras consideraciones'
    answer: 'La materia requiere disponer de 4hs semanales de atención a las actividades que proponen los profesores . Se recomienda organizarse para disponer de otro tanto para realizar prácticas y estudiar. Es decir, unas 8hs semanales en total.
    Se organizan espacios de consulta semanal con la estudiante asistente'
    image: "otros.jpg"
---
