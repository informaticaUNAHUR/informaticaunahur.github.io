---
layout: post
title: "(793) - Matemática para Informática 2"
description: 'Materia del segundo cuatrimestre del primer año'
date:   2022-08-07 17:46:41 -0300
categories: Materias
by: 'Informatica UNAHUR'
icon: 'list'
questions:
  - question: 'OBJETIVOS'
    answer: ''
    programa: "793-202206-Matematica-para-Informatica-2.pdf"
    modalidad: "MODALIDAD COMBINADA"
  - question: '¿Cómo se cursa?'
    answer: 'Cada semana de cursada alternadamente o en forma presencial o virtual. Se aborda un contenido diferente y se realizan encuentros con explicaciones teóricas y resoluciones prácticas. Se trabaja además con mucho material en el campus.<br/>
    '
  - question: 'Otras consideraciones'
    answer: 'La materia tiene una carga horaria real de 4hs semanales. Es ideal dedicarle unas 8hs semanales en total para poder estudiar, practicar y consultar.'
    image: "otros.jpg"
---
