---
layout: post
title: "(792) - Programación Estructurada"
description: 'Materia del segundo cuatrimestre del primer año'
date:   2022-08-07 17:46:41 -0300
categories: Materias
by: 'Informatica UNAHUR'
icon: 'credit-card'
questions:
  - question: 'OBJETIVOS'
    answer: ''
    programa: ""
    modalidad: "MODALIDAD COMBINADA"
  - question: '¿Cómo se cursa virtualmente?'
    answer: 'Se utiliza el Campus Virtual como espacio donde se informan novedades y se van habilitando contenidos semanalmente.
    Se dictan clases presenciales semanales obligatorias para el desarrollo teórico con ejercicios de aplicación.
    Se dictan clases de prácticas virtuales de resolución de ejercicios que pueden ser sincrónicas o asincrónicas.'
  - question: 'Otras consideraciones'
    answer: 'La materia requiere disponer de 4hs semanales de atención a las actividades sincrónicas que propone el docente.Se recomienda organizarse para disponer de otro tanto para realizar prácticas y estudiar. Es decir, unas 8hs semanales en total.
    '
    image: "otros.jpg"
---
