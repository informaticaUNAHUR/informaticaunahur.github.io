---
layout: post
title: (Elec_TUP_II)-Electiva II
date: 2023-07-01 17:15:42
categories: Materias
by: 'Informatica UNAHUR'
icon: 'cpu'
questions:
  - question: 'CARRERAS'
    answer: 'Tecnicatura Universitaria en Programación-'
---
